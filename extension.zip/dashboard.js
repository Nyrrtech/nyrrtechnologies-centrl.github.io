// ============================================================
//  NEWS SENTIMENT RADAR — EXTENSION DASHBOARD (per-page mode)
//  esc is already defined by auth.js – do NOT redeclare it
//
//  This build only ever looks at the tab the person opened the
//  extension from: it does not crawl any predefined sources/
//  categories and has no topic search. Two modes only:
//    - "article" page  -> analyze that one article
//    - "site" page      -> analyze the article links found on it
// ============================================================

// ==================== GLOBALS & CONFIG ====================
let settings = { aiProvider: 'mistral', anthropicKey: '', mistralKey: '' };
let stories = [], activeFilter = null, currentBrief = null;
let pageData = null; // last extraction result from the source tab
let _lastPipelineRun = 0;
const PIPELINE_COOLDOWN_MS = 60000;

// Rate Limit Mechanics
let _aiRateLimitPaused = false;
let _aiRateLimitResumeTime = 0;

function updateRateLimitStatus(isPaused, seconds) {
  const progressDiv = document.getElementById('progressMsg');
  const msg = `⚠️ AI Rate Limit reached. Pausing for ${seconds}s before resuming...`;
  if (isPaused) {
    if (progressDiv) {
      if (!progressDiv.dataset.originalText) progressDiv.dataset.originalText = progressDiv.textContent;
      progressDiv.innerHTML = `<span class="spinner" style="border-top-color: var(--accent);"></span> <span style="color: var(--accent); font-weight: 600;">${msg}</span>`;
    }
  } else if (progressDiv && progressDiv.dataset.originalText) {
    progressDiv.textContent = progressDiv.dataset.originalText;
    progressDiv.dataset.originalText = '';
  }
}

async function checkAndDelayIfRateLimited() {
  if (_aiRateLimitPaused) {
    let now = Date.now();
    while (now < _aiRateLimitResumeTime) {
      const waitTime = _aiRateLimitResumeTime - now;
      updateRateLimitStatus(true, Math.ceil(waitTime / 1000));
      await new Promise(r => setTimeout(r, Math.min(1000, waitTime)));
      now = Date.now();
    }
    _aiRateLimitPaused = false;
    updateRateLimitStatus(false);
  }
}

function showSettingsMessage(msg, isError = false) {
  const msgDiv = document.getElementById('settingsMsg');
  if (msgDiv) {
    msgDiv.textContent = msg;
    msgDiv.style.color = isError ? 'var(--red)' : 'var(--accent)';
    setTimeout(() => { msgDiv.textContent = ''; }, 3000);
  }
}

function timeAgo(iso) {
  if (!iso) return '';
  const s = (Date.now() - new Date(iso)) / 1000;
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  return Math.floor(s / 86400) + 'd';
}

function safeJsonParse(str, fallback = {}) {
  if (!str) return fallback;
  try {
    let c = str.replace(/```json\s*|```\s*$/g, '').trim();
    const m = c.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (m) c = m[0];
    c = c.replace(/,\s*}/g, '}').replace(/,\s*]/g, ']');
    return JSON.parse(c);
  } catch (e) { return fallback; }
}

async function runConcurrent(tasks, limit, onEach) {
  let nextIdx = 0;
  async function worker() {
    while (nextIdx < tasks.length) {
      const idx = nextIdx++;
      let result = null;
      try { result = await tasks[idx](); } catch (e) {}
      if (onEach) await onEach(idx, result);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, tasks.length) }, worker));
}

// ==================== AI CALLS ====================
async function callAI({ prompt, maxTokens = 600, apiKey, provider }) {
  await checkAndDelayIfRateLimited();
  if (provider === 'anthropic') {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-3-haiku-20240307', max_tokens: maxTokens, messages: [{ role: 'user', content: prompt }] })
    });
    if (r.status === 429) {
      _aiRateLimitPaused = true;
      _aiRateLimitResumeTime = Date.now() + 16000;
      throw new Error('429 Rate Limit Exceeded');
    }
    if (!r.ok) { const e = await r.text(); throw new Error(`Anthropic ${r.status}: ${e.slice(0,100)}`); }
    const d = await r.json(); return d.content[0].text;
  } else {
    const r = await fetch('https://api.mistral.ai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      body: JSON.stringify({ model: 'mistral-large-latest', max_tokens: maxTokens, messages: [{ role: 'user', content: prompt }] })
    });
    if (r.status === 429) {
      _aiRateLimitPaused = true;
      _aiRateLimitResumeTime = Date.now() + 16000;
      throw new Error('429 Rate Limit Exceeded');
    }
    if (!r.ok) { const e = await r.text(); throw new Error(`Mistral ${r.status}: ${e.slice(0,120)}`); }
    const d = await r.json(); return d.choices[0].message.content;
  }
}

async function callAIWithRetry({ prompt, maxTokens = 600, apiKey, provider, retries = 5, delayMs = 1000 }) {
  let lastErr;
  for (let i = 1; i <= retries; i++) {
    try {
      await checkAndDelayIfRateLimited();
      return await callAI({ prompt, maxTokens, apiKey, provider });
    }
    catch (e) {
      lastErr = e;
      const is429 = e.message.includes('429') || e.message.includes('Rate Limit');
      const is5xx = /\b5\d{2}\b/.test(e.message);

      if (is429) {
        _aiRateLimitPaused = true;
        _aiRateLimitResumeTime = Date.now() + 16000;
        await checkAndDelayIfRateLimited();
        continue;
      }

      if (!is5xx || i === retries) throw e;
      const wait = delayMs * Math.pow(2, i-1) + Math.random()*300;
      await new Promise(r => setTimeout(r, wait));
    }
  }
  throw lastErr;
}

async function analyzeArticle(article, apiKey, provider) {
  const bodyExcerpt = article.fullText ? `\nExcerpt: "${article.fullText.slice(0, 1200).replace(/"/g, '\\"')}"` : '';
  const descLine = article.description ? `\nSummary: "${article.description.replace(/"/g, '\\"')}"` : '';
  const prompt = `Analyze this news item.\nHeadline: "${(article.title||'').replace(/"/g, '\\"')}"${descLine}${bodyExcerpt}\nReturn ONLY JSON: {"emotion":"fear|anger|joy|sadness|surprise|neutral","sentiment":"positive|negative|neutral","intonation":"informative|alarming|hopeful","confidence":0.0,"keywords":["w1","w2"],"explanation":"short"}`;
  try {
    const raw = await callAIWithRetry({ prompt, maxTokens: 260, apiKey, provider, retries: 2, delayMs: 600 });
    return safeJsonParse(raw, { emotion: 'neutral', sentiment: 'neutral', intonation: 'informative', confidence: 0.5, keywords: [], explanation: '' });
  } catch (e) {
    return { emotion: 'neutral', sentiment: 'neutral', intonation: 'informative', confidence: 0.5, keywords: [], explanation: '' };
  }
}

// ==================== PAGE EXTRACTION (current tab only) ====================
// This function is injected into the SOURCE tab via chrome.scripting.
// It must be fully self-contained — no references to outer-scope variables.
function extractPageData() {
  function clean(s) { return (s || '').replace(/\s+/g, ' ').trim(); }

  const ogType = document.querySelector('meta[property="og:type"]')?.content || '';
  const articleEl = document.querySelector('article');
  const paragraphs = Array.from(document.querySelectorAll('article p, main p, p'));
  const totalTextLen = paragraphs.reduce((a, p) => a + (p.innerText || '').length, 0);
  const h1 = document.querySelector('h1');
  const isArticle = !!articleEl || ogType === 'article' || (totalTextLen > 1200 && paragraphs.length > 4);

  const title = clean(
    document.querySelector('meta[property="og:title"]')?.content ||
    h1?.innerText ||
    document.title
  );
  const description = clean(
    document.querySelector('meta[name="description"]')?.content ||
    document.querySelector('meta[property="og:description"]')?.content ||
    ''
  );
  const published =
    document.querySelector('meta[property="article:published_time"]')?.content ||
    document.querySelector('time')?.getAttribute('datetime') || '';

  if (isArticle) {
    let bodyText = articleEl ? clean(articleEl.innerText) : '';
    if (!bodyText || bodyText.length < 200) bodyText = clean(paragraphs.map(p => p.innerText).join(' '));
    return {
      mode: 'article',
      url: location.href,
      hostname: location.hostname,
      title,
      description,
      text: bodyText.slice(0, 8000),
      publishedAt: published || new Date().toISOString()
    };
  }

  // SITE / LISTING mode — gather candidate article links visible on this page only.
  const seen = new Set();
  const links = [];
  Array.from(document.querySelectorAll('a[href]')).forEach(a => {
    if (links.length >= 40) return;
    const text = clean(a.innerText);
    if (text.length < 20 || text.length > 200) return;
    let href;
    try { href = new URL(a.getAttribute('href'), location.href).href; } catch (e) { return; }
    if (!href.startsWith('http')) return;
    try { if (new URL(href).hostname !== location.hostname) return; } catch (e) { return; }
    if (seen.has(href) || href === location.href) return;
    seen.add(href);
    let snippet = '';
    const card = a.closest('article, li, .card, .post, .entry') || a.parentElement;
    if (card) snippet = clean(card.innerText).slice(0, 220);
    links.push({ title: text, url: href, description: snippet });
  });

  return {
    mode: 'site',
    url: location.href,
    hostname: location.hostname,
    title: clean(document.title),
    description,
    links
  };
}

async function getSourceTab() {
  // The dashboard now runs as the toolbar popup, so the tab the person was
  // actually looking at is simply the active tab in the current window.
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab || null;
}

async function extractCurrentPage() {
  const tab = await getSourceTab();
  if (!tab) throw new Error('No active page found.');
  if (!tab.url || !/^https?:\/\//.test(tab.url)) throw new Error('This page cannot be analyzed (unsupported URL).');
  const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractPageData });
  if (!result) throw new Error('Could not read the page content.');
  return result;
}

// ==================== UI RENDERING ====================
const emojiMap = { fear:'😨', anger:'😠', sadness:'😢', joy:'😄', surprise:'😲', neutral:'😐' };

function renderPageInfo() {
  const body = document.getElementById('pageInfoBody');
  if (!body) return;
  if (!pageData) {
    body.innerHTML = `<div class="empty-icon">📡</div>Open this extension from a news site or article tab, then click Analyze.`;
    body.className = 'empty';
    return;
  }
  body.className = '';
  const modeBadge = pageData.mode === 'article'
    ? `<span class="badge badge-pos">📰 Article</span>`
    : `<span class="badge">🗂️ Site / listing</span>`;
  const countNote = pageData.mode === 'site' ? ` · ${(pageData.links||[]).length} links found` : '';
  body.innerHTML = `<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px">${modeBadge}<span style="font-size:11px;color:var(--text-hint)">${esc(pageData.hostname || '')}${countNote}</span></div><div style="font-weight:700;font-size:14px;margin-bottom:4px">${esc(pageData.title || '')}</div><div style="font-size:12px;color:var(--text-sec);word-break:break-all"><a href="${esc(pageData.url)}" target="_blank" rel="noopener">${esc(pageData.url)}</a></div>`;
}

function buildStoryCardHTML(s, hasBriefs) {
  const emoji = emojiMap[s.emotion] || '😐';
  const sentCls = s.sentiment === 'positive' ? 'badge-pos' : s.sentiment === 'negative' ? 'badge-neg' : 'badge-neutral';
  return `<div class="story-card" data-url="${esc(s.url)}"><div class="card-top"><div class="emotion-dot">${emoji}</div><div class="card-body"><div class="card-meta"><span class="badge">${esc(s.source)}</span><span class="badge ${sentCls}">${esc(s.sentiment)||'neutral'}</span><span class="ts">${timeAgo(s.publishedAt)}</span></div><div class="card-title"><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)}</a></div>${s.explanation ? `<div class="card-explain">${esc(s.explanation)}</div>` : ''}<div class="card-kw">${(s.keywords||[]).slice(0,3).map(k=>`<span class="kw">${esc(k)}</span>`).join('')}</div><div class="conf-row"><span style="font-size:10px;color:var(--text-hint)">${Math.round((s.confidence||0.5)*100)}%</span><div class="conf-track"><div class="conf-fill" style="width:${Math.round((s.confidence||0.5)*100)}%"></div></div></div></div></div><div class="card-actions"><button class="act-btn brief-btn ${hasBriefs ? '' : 'locked-btn'}" data-url="${esc(s.url)}">📝 Brief${hasBriefs ? '' : ' 🔒'}</button>${s.fullText ? `<button class="act-btn hz-btn" data-url="${esc(s.url)}">✨ Humanize</button>` : ''}<button class="act-btn open-btn" data-url="${esc(s.url)}">↗ Open</button></div></div>`;
}

function bindCardButtons(container) {
  container.querySelectorAll('.brief-btn').forEach(btn => btn.addEventListener('click', async () => {
    if (!await canUseBriefs()) { renderUpsellBanner('briefsContent', 'briefs'); document.querySelector('.db-tab[data-tab="briefs"]').click(); return; }
    const story = stories.find(s => s.url === btn.dataset.url);
    if (story) generateBrief(story);
  }));
  container.querySelectorAll('.hz-btn').forEach(btn => btn.addEventListener('click', () => {
    const story = stories.find(s => s.url === btn.dataset.url);
    if (!story?.fullText) return;
    const input = document.getElementById('hzInput');
    if (input) input.value = story.fullText;
    document.querySelector('.db-tab[data-tab="humanizer"]').click();
  }));
  container.querySelectorAll('.open-btn').forEach(btn => btn.addEventListener('click', () => window.open(btn.dataset.url, '_blank', 'noopener')));
}

async function renderStories() {
  const container = document.getElementById('storyList');
  if (!container) return;
  const hasBriefs = await canUseBriefs();
  let filtered = stories;
  if (activeFilter) filtered = filtered.filter(s => s.emotion === activeFilter);
  if (!filtered.length) { container.innerHTML = '<div class="empty"><div class="empty-icon">📭</div>No stories match this filter.</div>'; return; }
  container.innerHTML = filtered.map(s => buildStoryCardHTML(s, hasBriefs)).join('');
  bindCardButtons(container);
}

async function appendStoryCard(story) {
  const container = document.getElementById('storyList');
  if (!container) return;
  const hasBriefs = await canUseBriefs();
  if (container.querySelector('.empty')) container.innerHTML = '';
  if (activeFilter && story.emotion !== activeFilter) return;
  container.insertAdjacentHTML('beforeend', buildStoryCardHTML(story, hasBriefs));
  bindCardButtons(container);
}

function renderStats() {
  const strip = document.getElementById('statsStrip');
  if (!strip || !stories.length) { if (strip) strip.style.display = 'none'; return; }
  strip.style.display = 'grid';
  const counts = { positive:0, negative:0, neutral:0 };
  const emotions = {};
  stories.forEach(s => { counts[s.sentiment] = (counts[s.sentiment]||0)+1; emotions[s.emotion] = (emotions[s.emotion]||0)+1; });
  const topE = Object.entries(emotions).sort((a,b)=>b[1]-a[1])[0];
  strip.innerHTML = `<div class="stat-box"><div class="stat-value" style="color:var(--green)">${counts.positive}</div><div class="stat-label">Positive</div></div><div class="stat-box"><div class="stat-value" style="color:var(--red)">${counts.negative}</div><div class="stat-label">Negative</div></div><div class="stat-box"><div class="stat-value" style="color:var(--text-hint)">${counts.neutral}</div><div class="stat-label">Neutral</div></div><div class="stat-box"><div class="stat-value">${topE ? emojiMap[topE[0]]||'😐' : '—'}</div><div class="stat-label">Top emotion</div></div>`;
}

function renderFilterRow() {
  const row = document.getElementById('filterRow');
  if (!row || !stories.length) { if (row) row.style.display = 'none'; return; }
  const emotions = [...new Set(stories.map(s=>s.emotion))];
  row.style.display = 'flex';
  row.innerHTML = `<button class="filter-chip${!activeFilter ? ' active' : ''}" data-filter="">All Emotions</button>` + emotions.map(e=>`<button class="filter-chip${activeFilter===e ? ' active' : ''}" data-filter="${esc(e)}">${emojiMap[e]||''} ${esc(e)}</button>`).join('');
  row.querySelectorAll('.filter-chip').forEach(chip => chip.addEventListener('click', () => {
    activeFilter = chip.dataset.filter || null;
    row.querySelectorAll('.filter-chip').forEach(c=>c.classList.toggle('active',c===chip));
    renderStories();
  }));
}

// ==================== BRIEF & DRAFT GENERATION ====================
async function generateBrief(story) {
  if (!await canUseBriefs()) { renderUpsellBanner('briefsContent', 'briefs'); document.querySelector('.db-tab[data-tab="briefs"]').click(); return; }
  const apiKey   = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  const briefsDiv = document.getElementById('briefsContent');
  if (briefsDiv) briefsDiv.innerHTML = '<div class="empty"><span class="spinner"></span> Creating brief…</div>';
  document.querySelector('.db-tab[data-tab="briefs"]').click();
  const bodyHint = story.fullText ? `\nExcerpt: "${story.fullText.slice(0,800).replace(/"/g,'\\"')}"` : '';
  const prompt = `Story: "${story.title.replace(/"/g, '\\"')}".${bodyHint} Return ONLY JSON: {"headline":"","primaryKeyword":"","secondaryKeywords":[],"angle":"","outline":["s1","s2","s3","s4"],"audience":"","wordCount":1200,"keyPoints":[],"callToAction":""}`;
  try {
    const raw   = await callAIWithRetry({ prompt, maxTokens: 700, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 800 });
    const brief = safeJsonParse(raw, {});
    currentBrief = Object.keys(brief).length > 2 ? brief : { headline: story.title.slice(0, 120), angle: `Analysis of "${story.title}"`, primaryKeyword: story.keywords?.[0] || 'news', secondaryKeywords: story.keywords?.slice(1, 4) || [], outline: ['Introduction', 'Main developments', 'Expert opinions', 'Conclusion'], audience: 'News readers', wordCount: 1000, keyPoints: [], callToAction: 'Read more' };
    renderBrief(currentBrief);
  } catch (e) { if (briefsDiv) briefsDiv.innerHTML = `<div class="error-msg">Brief error: ${esc(e.message)}</div>`; }
}

async function generateBriefFromTopic(topic) {
  const apiKey   = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  const briefsDiv = document.getElementById('briefsContent');
  if (!apiKey) { if (briefsDiv) briefsDiv.innerHTML = '<div class="error-msg">⚠️ Add your API key in Settings first.</div>'; document.querySelector('.db-tab[data-tab="settings"]').click(); return; }
  if (briefsDiv) briefsDiv.innerHTML = `<div class="empty"><span class="spinner"></span> Generating brief for "${esc(topic)}"…</div>`;
  document.querySelector('.db-tab[data-tab="briefs"]').click();
  const escaped = topic.replace(/"/g, '\\"');
  const prompt  = `Content brief for topic "${escaped}". Return ONLY JSON: {"headline":"","primaryKeyword":"${escaped}","secondaryKeywords":[],"angle":"","outline":["s1","s2","s3","s4"],"audience":"professionals","wordCount":1000,"keyPoints":[],"callToAction":""}`;
  try {
    const raw   = await callAIWithRetry({ prompt, maxTokens: 600, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 800 });
    const brief = safeJsonParse(raw, {});
    if (!brief.headline || !brief.angle) throw new Error('Incomplete response');
    currentBrief = brief; renderBrief(brief);
  } catch (e) {
    const fallback = { headline: `${topic} – Analysis`, angle: `Deep dive into ${topic}.`, primaryKeyword: topic, secondaryKeywords: [], outline: ['Introduction', 'Key facts', 'Developments', 'Conclusion'], audience: 'General readers', wordCount: 1000, keyPoints: [], callToAction: 'Learn more' };
    currentBrief = fallback; renderBrief(fallback);
  }
}

async function generateBriefFromTopicWithTone(topic, tone) {
  const apiKey   = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  const briefsDiv = document.getElementById('briefsContent');
  if (!apiKey) { if (briefsDiv) briefsDiv.innerHTML = '<div class="error-msg">⚠️ Add your API key in Settings first.</div>'; document.querySelector('.db-tab[data-tab="settings"]').click(); return; }
  if (briefsDiv) briefsDiv.innerHTML = `<div class="empty"><span class="spinner"></span> Generating brief for "${esc(topic)}"…</div>`;
  document.querySelector('.db-tab[data-tab="briefs"]').click();
  const ctxStories = stories.filter(s => `${s.title} ${s.description||''}`.toLowerCase().includes(topic.toLowerCase())).slice(0, 4);
  const context    = ctxStories.length ? '\nRelated:\n' + ctxStories.map(s => `- ${s.title} (${s.source})`).join('\n') : '';
  const toneNote   = tone ? ` ${tone} tone.` : '';
  const escaped    = topic.replace(/"/g, '\\"');
  const prompt     = `You are an expert content strategist. Create a detailed article brief for: "${escaped}".${toneNote}${context}\nReturn ONLY valid JSON:\n{"headline":"","primaryKeyword":"${escaped}","secondaryKeywords":[],"angle":"","outline":["s1","s2","s3","s4","s5"],"audience":"","wordCount":1200,"keyPoints":[],"callToAction":"","tone":"${tone || 'neutral'}"}`;
  try {
    const raw   = await callAIWithRetry({ prompt, maxTokens: 700, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 800 });
    const brief = safeJsonParse(raw, {});
    if (!brief.headline || !brief.angle) throw new Error('Incomplete response');
    currentBrief = brief; renderBrief(brief);
  } catch (e) {
    const fallback = { headline: `${topic} – ${tone ? tone.toUpperCase() + ' ' : ''}Analysis`, angle: `A ${tone || 'balanced'} look at ${topic}.`, primaryKeyword: topic, secondaryKeywords: [], outline: ['Introduction', 'Background', 'Developments', 'Implications', 'Conclusion'], audience: 'General readers', wordCount: 1100, keyPoints: [], callToAction: 'Share your thoughts' };
    currentBrief = fallback; renderBrief(fallback);
  }
}

async function renderBrief(brief) {
  const briefsDiv = document.getElementById('briefsContent');
  if (!briefsDiv) return;
  const hasDrafts = await canUseDrafts();
  briefsDiv.innerHTML = `<div class="brief-card"><div class="brief-headline">${esc(brief.headline)}</div><div class="brief-angle">🎯 ${esc(brief.angle)}</div><div style="font-size:12px;margin-bottom:8px"><strong>Primary keyword:</strong> ${esc(brief.primaryKeyword)}</div><div style="font-size:12px;margin-bottom:6px"><strong>Outline:</strong></div><ol class="brief-outline">${(brief.outline || []).map(o => `<li>${esc(o)}</li>`).join('')}</ol><div class="card-actions"><button id="genDraftBtn" class="act-btn ${hasDrafts ? '' : 'locked-btn'}">✍️ Generate Draft${hasDrafts ? '' : ' 🔒'}</button><button id="copyBriefBtn" class="act-btn">⎘ Copy</button></div></div>`;
  document.getElementById('genDraftBtn')?.addEventListener('click', async () => { if (!await canUseDrafts()) { renderUpsellBanner('draftContent', 'drafts'); document.querySelector('.db-tab[data-tab="draft"]').click(); return; } generateDraft(brief); });
  document.getElementById('copyBriefBtn')?.addEventListener('click', () => navigator.clipboard?.writeText(JSON.stringify(brief, null, 2)));
}

async function generateDraft(brief) {
  if (!await canUseDrafts()) { renderUpsellBanner('draftContent', 'drafts'); document.querySelector('.db-tab[data-tab="draft"]').click(); return; }
  const apiKey   = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  if (!apiKey) { document.getElementById('draftContent').innerHTML = '<div class="error-msg">Add an API key in Settings first.</div>'; return; }
  const draftDiv = document.getElementById('draftContent');
  if (draftDiv) draftDiv.innerHTML = '<div class="empty"><span class="spinner"></span> Writing draft (30–60s)…</div>';
  document.querySelector('.db-tab[data-tab="draft"]').click();
  const prompt = `Write a ${brief.wordCount || 1000}-word AP-style article.\nHeadline: ${brief.headline}.\nKeyword: ${brief.primaryKeyword}.\nOutline: ${(brief.outline || []).join(', ')}.\nAngle: ${brief.angle}.\nAudience: ${brief.audience || 'general readers'}.\nUse engaging lede, short paragraphs, subheadings. No fabricated quotes.`;
  try {
    const draft = await callAIWithRetry({ prompt, maxTokens: 2500, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 1200 });
    const fname = `${(brief.primaryKeyword || 'draft').replace(/\s+/g, '-')}.md`;
    if (draftDiv) { draftDiv.innerHTML = `<div class="draft-output">${esc(draft)}</div>${makeDraftActions(draft, fname)}`; bindDraftActions(draft, fname); }
  } catch (e) { if (draftDiv) draftDiv.innerHTML = `<div class="error-msg">Draft error: ${esc(e.message)}</div>`; }
}

async function generateDraftFromPrompt(userPrompt, wordCount, style) {
  const apiKey   = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  if (!apiKey) { document.getElementById('draftContent').innerHTML = '<div class="error-msg">Add an API key in Settings first.</div>'; return; }
  const draftDiv = document.getElementById('draftContent');
  if (draftDiv) draftDiv.innerHTML = '<div class="empty"><span class="spinner"></span> Writing draft (30–60s)…</div>';
  document.querySelector('.db-tab[data-tab="draft"]').click();
  const prompt = `Write a ${wordCount}-word article in ${style}.\nUser brief: ${userPrompt}\nRequirements:\n- Follow the brief exactly\n- Engaging lede/opening\n- Short paragraphs\n- Clear subheadings\n- Do NOT fabricate quotes or statistics\n- End with a strong conclusion`;
  try {
    const draft = await callAIWithRetry({ prompt, maxTokens: 2500, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 1200 });
    if (draftDiv) { draftDiv.innerHTML = `<div class="draft-output">${esc(draft)}</div>${makeDraftActions(draft, 'draft-' + Date.now() + '.md')}`; bindDraftActions(draft, 'draft-' + Date.now() + '.md'); }
  } catch (e) { if (draftDiv) draftDiv.innerHTML = `<div class="error-msg">Draft error: ${esc(e.message)}</div>`; }
}

function makeDraftActions(text, filename) {
  return `<div class="draft-actions"><button id="copyDraftBtn" class="act-btn">📋 Copy Draft</button><div class="tone-selector">🎭 Tone<select id="humanizerToneSelect"><option value="casual">Casual</option><option value="professional">Professional</option><option value="witty">Witty</option><option value="empathetic">Empathetic</option><option value="simple">Simple &amp; Clear</option></select></div><button id="humanizeDraftBtn" class="act-btn">✨ Humanize</button><button id="exportMdBtn" class="act-btn">⬇ Export MD</button></div>`;
}

function bindDraftActions(text, filename) {
  document.getElementById('copyDraftBtn')?.addEventListener('click', () => navigator.clipboard?.writeText(text));
  document.getElementById('exportMdBtn')?.addEventListener('click', () => { const blob = new Blob([text], { type: 'text/markdown' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename || `draft-${Date.now()}.md`; a.click(); });
  document.getElementById('humanizeDraftBtn')?.addEventListener('click', () => {
    const tone = document.getElementById('humanizerToneSelect')?.value || 'casual';
    humanizeDraft(text, tone);
  });
}

function stripMarkdown(text) {
  if (!text) return '';
  let r = text;
  r = r.replace(/```[\s\S]*?```/g, '');
  r = r.replace(/`([^`]+)`/g, '$1');
  r = r.replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1');
  r = r.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');
  r = r.replace(/(\*\*|__)(.*?)\1/g, '$2');
  r = r.replace(/(\*|_)(.*?)\1/g, '$2');
  r = r.replace(/^[-\*_]{3,}\s*$/gm, '');
  r = r.replace(/^#{1,6}\s+/gm, '');
  r = r.replace(/^\s*[-*+]\s+/gm, '');
  r = r.replace(/^\s*\d+\.\s+/gm, '');
  r = r.replace(/\n{3,}/g, '\n\n');
  return r.trim();
}

// ==================== ADVANCED HUMANIZER ====================
const HUMANIZER_BANNED   = ['delve','leverage','revolutionize','groundbreaking','unprecedented','game-changer','transformative','cutting-edge','holistic','synergy','paradigm','disruptive','innovative','robust','seamless','unlock','empower','streamline','optimize','utilize','harness','realm','moreover','furthermore','notably','consequently','accordingly','in conclusion','to summarize','it is important to note','needless to say',"in today's fast-paced world",'in the digital age','moving forward','going forward','dive deep'];
const HUMANIZER_PERSONAS = { journalist: { voice: 'seasoned investigative journalist with 15+ years experience', traits: ['Lead with the most surprising fact','Use inverted pyramid','Name real people specifically','Insert short punchy paragraphs','Challenge assumptions','Use em-dashes for asides','Occasionally address the reader'] }, blogger: { voice: 'enthusiastic personal blogger with deep knowledge', traits: ['Start with a personal anecdote','Use "I" occasionally','Ask rhetorical questions','Use casual connectors','Break into short paragraphs','Use parenthetical asides','Use "you" frequently'] }, expert: { voice: 'authoritative subject-matter expert', traits: ['Use precise terminology','Reference historical context','Acknowledge nuance','Use hedging language',"Be willing to say what others get wrong",'Short declarative sentences after complex ones'] }, storyteller: { voice: 'narrative journalist who makes dry topics compelling', traits: ['Open with a scene','Use sensory language','Build tension through sequencing','Vary sentence length dramatically','End paragraphs with a turn'] }, analyst: { voice: 'sharp business/policy analyst', traits: ['Lead with the key takeaway','Use numbered breakdowns','Contrast expectation vs reality','Reference real-world implications','Keep sentences tight','Be direct about uncertainty'] } };
const BYPASS_INSTRS      = { light: 'Make moderate changes: replace AI buzzwords, add contractions, vary sentence length. Target: ~30% reduction.', medium: 'Significantly rewrite while keeping all facts. Restructure 40%+ of sentences, add 3-5 natural human quirks. Target: ~65% reduction.', aggressive: 'Deeply transform — keep ONLY facts, data, named entities. Rewrite every sentence. Target: ~85% reduction.' };
const SEO_INSTRS         = { none: '', basic: '\n\nSEO (Basic): Use focus keyword naturally in first paragraph and 2+ other places. Active voice.', full: '\n\nSEO (Full): Keyword in first 100 words, a heading, and final paragraph. Include 3-5 LSI terms.' };

async function runAdvancedHumanizer({ text, persona, tone, bypassLevel, seoMode, focusKeyword, targetDiv, onComplete }) {
  const apiKey = settings.aiProvider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  if (!apiKey) { if (targetDiv) targetDiv.innerHTML = '<div class="error-msg">⚠️ Add your API key in Settings first.</div>'; return null; }
  const personaData = HUMANIZER_PERSONAS[persona] || HUMANIZER_PERSONAS.journalist;
  const bypassInstr = BYPASS_INSTRS[bypassLevel] || BYPASS_INSTRS.medium;
  const seoInstr    = SEO_INSTRS[seoMode] || '';
  const bannedList  = HUMANIZER_BANNED.join('", "');
  const keywordLine = focusKeyword ? `\nFOCUS KEYWORD: "${focusKeyword}"` : '';
  const toneGuide   = { casual: 'warm, conversational — contractions, short paragraphs', professional: 'polished, authoritative, active voice', witty: 'sharp, clever, light humour', empathetic: 'warm, use "we" and "you", compassionate', simple: 'plain English, max 15-word sentences' };
  const passes      = bypassLevel === 'light' ? 1 : bypassLevel === 'medium' ? 2 : 3;
  const setProgress = (msg, pct) => { const p = document.getElementById('hzProgressMsg'); const f = document.getElementById('hzProgFill'); if (p) p.innerHTML = msg; if (f) f.style.width = pct + '%'; };
  const addBadge    = (label, color) => { const badges = document.getElementById('hzPassBadges'); if (!badges) return; const b = document.createElement('span'); b.style.cssText = `font-size:10px;padding:2px 9px;border-radius:20px;background:${color}22;color:${color};border:1px solid ${color}44`; b.textContent = label; badges.appendChild(b); };
  const passBadges  = document.getElementById('hzPassBadges');
  if (passBadges) passBadges.innerHTML = '';
  let current = text;
  try {
    setProgress('<span class="spinner"></span> Pass 1/' + passes + ': Restructuring & voice…', 10); addBadge('Pass 1: Structure', '#f5b042');
    const p1 = `You are a ${personaData.voice}. Rewrite with a completely new structure and voice.\nPERSONA TRAITS:\n${personaData.traits.map((t, i) => `${i + 1}. ${t}`).join('\n')}\nTONE: ${toneGuide[tone] || toneGuide.casual}\nBYPASS LEVEL: ${bypassInstr}${keywordLine}\nABSOLUTE RULES:\n1. NEVER use: "${bannedList}"\n2. Keep ALL facts accurate\n3. Vary sentence length dramatically\n4. Return ONLY the rewritten article.\n\nARTICLE:\n${current}`;
    current = await callAIWithRetry({ prompt: p1, maxTokens: 3200, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 1200 });
    setProgress('<span class="spinner"></span> Pass 1 complete.', 30);
    if (passes >= 2) {
      await new Promise(r => setTimeout(r, 500)); setProgress('<span class="spinner"></span> Pass 2/' + passes + ': Maximising burstiness…', 35); addBadge('Pass 2: Burstiness', '#8BC97F');
      const p2 = `Expert editor specialising in making AI-written text undetectable.\nEDITING TASKS:\n1. Restructure at least 3 of the 5 longest sentences\n2. Replace predictable word choices\n3. Remove: "moreover","furthermore","however","therefore","thus","additionally"\n4. Add 2-3 natural imperfections: comma splice, sentence starting with "And"/"But"\n5. No two consecutive sentences similar length${seoInstr}\nReturn ONLY the edited article.\n\nARTICLE:\n${current}`;
      current = await callAIWithRetry({ prompt: p2, maxTokens: 3200, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 1200 });
      setProgress('<span class="spinner"></span> Pass 2 complete.', 65);
    }
    if (passes >= 3) {
      await new Promise(r => setTimeout(r, 500)); setProgress('<span class="spinner"></span> Pass 3/' + passes + ': Scrubbing AI fingerprints…', 70); addBadge('Pass 3: Fingerprint Scrub', '#9B7EDE');
      const p3 = `Final AI fingerprint scrub.\nFINAL CHECKS:\n1. Any word used 3+ times? Vary with synonyms.\n2. 3+ consecutive sentences starting the same way? Fix.\n3. No two consecutive paragraphs the same length.\n4. Add if missing: mild surprise, mild opinion, short standalone sentence, rhetorical question.${focusKeyword ? `\n5. Confirm keyword "${focusKeyword}" appears in first 150 words.` : ''}\nReturn ONLY the final article.\n\nARTICLE:\n${current}`;
      current = await callAIWithRetry({ prompt: p3, maxTokens: 3200, apiKey, provider: settings.aiProvider, retries: 2, delayMs: 1200 });
      setProgress('✅ All passes complete.', 100); addBadge('✓ Done', '#f5b042');
    } else { setProgress('✅ Humanization complete.', 100); }
    setTimeout(() => { const p = document.getElementById('hzProgressMsg'); const f = document.getElementById('hzProgFill'); if (p) p.textContent = ''; if (f) f.style.width = '0%'; }, 3000);
    if (onComplete) onComplete(current);
    return current;
  } catch (e) {
    setProgress('', 0);
    if (targetDiv) targetDiv.innerHTML = `<div class="error-msg">Humanizer error (${esc(e.message)}). Check your API key.</div>`;
    return null;
  }
}

async function humanizeDraft(text, tone = 'casual') {
  const draftDiv = document.getElementById('draftContent');
  if (draftDiv) draftDiv.innerHTML = '<div class="empty"><span class="spinner"></span> Humanizing draft…</div>';
  const result = await runAdvancedHumanizer({ text, persona: 'journalist', tone, bypassLevel: 'medium', seoMode: 'basic', focusKeyword: '', targetDiv: draftDiv, onComplete: null });
  if (!result) return;
  if (draftDiv) {
    const fname = `humanized-${Date.now()}.md`;
    draftDiv.innerHTML = `<div class="draft-output">${esc(result)}</div>${makeDraftActions(result, fname)}`;
    bindDraftActions(result, fname);
  }
}

// ==================== SETTINGS & AUTH HELPERS ====================
async function getProfile() { return await window.loadProfile(); }
async function canUseBriefs() { const p = await getProfile(); return p?.canUseBriefs ?? false; }
async function canUseDrafts() { const p = await getProfile(); return p?.canUseDrafts ?? false; }

function renderUpsellBanner(containerId, feature) {
  const el = document.getElementById(containerId);
  if (!el) return;
  const labels = { briefs: 'AI briefs', drafts: 'AI drafts & humanizer', crawl: 'page analysis' };
  el.innerHTML = `<div style="background:#2A1E0A;border:1px solid rgba(245,176,66,0.25);border-radius:12px;padding:24px;text-align:center"><div style="font-size:1rem;margin-bottom:8px">🔒 ${esc(labels[feature] || feature)} is a Pro feature</div><div style="font-size:12px;color:var(--text-sec);margin-bottom:16px">Upgrade to unlock this feature.</div><a href="https://nyrrtechnologies-centrl.github.io/pricing.html" target="_blank"><button class="run-btn" style="margin:0 auto">View Pro Plan →</button></a></div>`;
}

async function loadSettingsUI() {
  const remote = await window.loadSettings();
  settings.aiProvider = remote.aiProvider || 'mistral';
  const el = id => document.getElementById(id);
  if (settings.aiProvider === 'mistral') {
    el('providerMistral')?.classList.add('active');
    el('providerAnthropic')?.classList.remove('active');
    if (el('groupMistralKey')) el('groupMistralKey').style.display = 'block';
    if (el('groupAnthropicKey')) el('groupAnthropicKey').style.display = 'none';
  } else {
    el('providerAnthropic')?.classList.add('active');
    el('providerMistral')?.classList.remove('active');
    if (el('groupAnthropicKey')) el('groupAnthropicKey').style.display = 'block';
    if (el('groupMistralKey')) el('groupMistralKey').style.display = 'none';
  }

  // Load decrypted API keys from Supabase (server-side decryption)
  const keyLoads = [];
  if (remote.anthropicKeySet) keyLoads.push(window.getApiKey('anthropic').then(k => { if (k) settings.anthropicKey = k; }));
  if (remote.mistralKeySet) keyLoads.push(window.getApiKey('mistral').then(k => { if (k) settings.mistralKey = k; }));
  await Promise.allSettled(keyLoads);

  if (remote.anthropicKeySet && el('anthropicKeyStatus')) {
    el('anthropicKeyStatus').style.display = 'flex';
    el('anthropicKeyStatusIcon').innerHTML = '✓';
    el('anthropicKeyStatusText').textContent = 'Key saved';
  }
  if (remote.mistralKeySet && el('mistralKeyStatus')) {
    el('mistralKeyStatus').style.display = 'flex';
    el('mistralKeyStatusIcon').innerHTML = '✓';
    el('mistralKeyStatusText').textContent = 'Key saved';
  }
}

async function saveSettingsHandler() {
  const el = id => document.getElementById(id);
  const newAnthropicKey = el('anthropicKey')?.value.trim() || '';
  const newMistralKey   = el('mistralKey')?.value.trim()   || '';

  if (newAnthropicKey) settings.anthropicKey = newAnthropicKey;
  if (newMistralKey)   settings.mistralKey   = newMistralKey;

  const saveBtn = el('saveSettingsBtn');
  const originalText = saveBtn?.textContent || '💾 Save settings';
  if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving…'; }

  try {
    await window.saveSettings({
      aiProvider: settings.aiProvider,
      anthropicKey: newAnthropicKey,
      mistralKey: newMistralKey
    });
    showSettingsMessage('✓ Settings saved successfully!', false);
    if (newAnthropicKey && el('anthropicKey')) el('anthropicKey').value = '';
    if (newMistralKey && el('mistralKey')) el('mistralKey').value = '';
    if (newAnthropicKey && el('anthropicKeyStatus')) {
      el('anthropicKeyStatus').style.display = 'flex';
      el('anthropicKeyStatusIcon').innerHTML = '✓';
      el('anthropicKeyStatusText').textContent = 'Key saved';
    }
    if (newMistralKey && el('mistralKeyStatus')) {
      el('mistralKeyStatus').style.display = 'flex';
      el('mistralKeyStatusIcon').innerHTML = '✓';
      el('mistralKeyStatusText').textContent = 'Key saved';
    }
    await window.loadSettings(true);
  } catch (err) {
    console.error('Save error:', err);
    showSettingsMessage('✗ ' + (err.message || 'Failed to save settings'), true);
  } finally {
    if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = originalText; }
  }
}

async function renderAccountPane(user) {
  const accountCard = document.getElementById('accountCard');
  if (accountCard) {
    const profile = await getProfile();
    const name = profile?.name || user.email.split('@')[0];
    const initials = name.split(' ').map(n=>n[0]).join('').toUpperCase().slice(0,2);
    accountCard.innerHTML = `<div class="account-row"><div class="account-avatar">${esc(initials)}</div><div><div style="font-weight:700">${esc(name)}</div><div style="font-size:12px;color:var(--text-sec)">${esc(user.email)}</div></div></div><button class="sh-btn" id="accountSignOutBtn">Sign out</button>`;
    document.getElementById('accountSignOutBtn')?.addEventListener('click', () => window.logout());
  }
}

async function renderTabLocks() {
  const profile   = await getProfile();
  const hasBriefs = profile?.canUseBriefs ?? false;
  const hasDrafts = profile?.canUseDrafts ?? false;
  const el = id => document.getElementById(id);
  if (el('briefsTabLock'))    el('briefsTabLock').textContent    = hasBriefs ? '' : '🔒';
  if (el('draftTabLock'))     el('draftTabLock').textContent     = hasDrafts ? '' : '🔒';
  if (el('humanizerTabLock')) el('humanizerTabLock').textContent = hasDrafts ? '' : '🔒';
}

async function renderSettingsTrialNote() {
  const profile = await getProfile();
  const el = document.getElementById('trialSettingsNote');
  if (!el) return;
  if (profile?.plan === 'trial' && profile.trialExpiresAt) {
    const days = Math.max(0, Math.ceil((new Date(profile.trialExpiresAt) - Date.now()) / 86400000));
    el.innerHTML = `<div class="trial-expiry-warning">⚡ Trial active — ${days} day${days !== 1 ? 's' : ''} remaining. <a href="https://nyrrtechnologies-centrl.github.io/pricing.html" target="_blank" style="color:var(--accent);font-weight:600">Upgrade to keep Pro access →</a></div>`;
  }
}

async function renderUsageBar() {
  const profile = await getProfile();
  const bar = document.getElementById('usageBar');
  if (!bar) return;
  if (!profile || profile.crawlLimit === Infinity || profile.crawlLimit >= 2000000) { bar.style.display = 'none'; return; }
  bar.style.display = 'flex';
  const count = await window.getCrawlCount();
  const pct   = Math.min((count / profile.crawlLimit) * 100, 100);
  const fill  = document.getElementById('usageFill');
  const cnt   = document.getElementById('usageCount');
  if (fill) { fill.style.width = pct + '%'; fill.style.background = pct >= 90 ? 'var(--red)' : 'var(--accent)'; }
  if (cnt)  cnt.textContent = `${count} / ${profile.crawlLimit}`;
}

// ==================== PAGE ANALYSIS PIPELINE ====================
// Replaces the old multi-source crawl: only ever looks at the tab the
// extension was opened from. No predefined sources/categories, no search.
async function runPageAnalysis() {
  const now = Date.now();
  if (now - _lastPipelineRun < PIPELINE_COOLDOWN_MS) {
    const secsLeft = Math.ceil((PIPELINE_COOLDOWN_MS - (now - _lastPipelineRun)) / 1000);
    const storyDiv = document.getElementById('storyList');
    if (storyDiv) storyDiv.innerHTML = `<div class="error-msg">⏳ Please wait <strong>${secsLeft}s</strong> before re-analyzing (rate limit).</div>`;
    return;
  }

  const crawlCheck = await window.canCrawl();
  if (!crawlCheck.ok) { renderUpsellBanner('storyList', 'crawl'); return; }

  let provider = settings.aiProvider;
  let apiKey = provider === 'anthropic' ? settings.anthropicKey : settings.mistralKey;
  if (!apiKey) {
    const remote = await window.loadSettings();
    const keyType = provider === 'anthropic' ? 'anthropic' : 'mistral';
    const keyIsSaved = provider === 'anthropic' ? remote.anthropicKeySet : remote.mistralKeySet;
    if (keyIsSaved) {
      const fetchedKey = await window.getApiKey(keyType);
      if (fetchedKey) {
        if (provider === 'anthropic') settings.anthropicKey = fetchedKey;
        else settings.mistralKey = fetchedKey;
        apiKey = fetchedKey;
      }
    }
    if (!apiKey) {
      const storyDiv = document.getElementById('storyList');
      if (storyDiv) storyDiv.innerHTML = `<div class="error-msg">⚠ Please enter your ${provider === 'anthropic' ? 'Anthropic' : 'Mistral'} API key in Settings.</div>`;
      document.querySelector('.db-tab[data-tab="settings"]').click();
      return;
    }
  }

  const analyzeBtn = document.getElementById('analyzeBtn');
  const progressDiv = document.getElementById('progressMsg');
  const progFill = document.getElementById('progFill');
  if (analyzeBtn) analyzeBtn.disabled = true;
  if (progressDiv) progressDiv.innerHTML = '<span class="spinner"></span> Reading the current page…';
  if (progFill) progFill.style.width = '5%';

  try {
    pageData = await extractCurrentPage();
  } catch (e) {
    if (progressDiv) progressDiv.textContent = '';
    if (progFill) progFill.style.width = '0%';
    if (analyzeBtn) analyzeBtn.disabled = false;
    const storyDiv = document.getElementById('storyList');
    if (storyDiv) storyDiv.innerHTML = `<div class="error-msg">⚠ ${esc(e.message)}</div>`;
    return;
  }
  renderPageInfo();

  try {
    await window.incrementCrawlCount();
  } catch (e) {
    if (analyzeBtn) analyzeBtn.disabled = false;
    if (progressDiv) progressDiv.textContent = '';
    if (progFill) progFill.style.width = '0%';
    renderUpsellBanner('storyList', 'crawl');
    return;
  }
  _lastPipelineRun = Date.now();
  renderUsageBar();
  activeFilter = null;

  // Build the work list: one item for an article page, or one item per
  // detected link for a site/listing page.
  let raw = [];
  if (pageData.mode === 'article') {
    raw = [{
      source: pageData.hostname, platform: 'article', title: pageData.title,
      url: pageData.url, description: pageData.description, fullText: pageData.text,
      publishedAt: pageData.publishedAt
    }];
  } else {
    raw = (pageData.links || []).slice(0, 30).map(l => ({
      source: pageData.hostname, platform: 'site', title: l.title,
      url: l.url, description: l.description, publishedAt: new Date().toISOString()
    }));
  }

  if (!raw.length) {
    if (progressDiv) progressDiv.textContent = '';
    if (progFill) progFill.style.width = '0%';
    if (analyzeBtn) analyzeBtn.disabled = false;
    const storyDiv = document.getElementById('storyList');
    if (storyDiv) storyDiv.innerHTML = '<div class="empty"><div class="empty-icon">📭</div>No article content or links were found on this page.</div>';
    return;
  }

  stories = [];
  const storyContainer = document.getElementById('storyList');
  if (storyContainer) storyContainer.innerHTML = `<div class="empty"><span class="spinner"></span> Analyzing ${raw.length} item${raw.length>1?'s':''} — results appear as they're ready…</div>`;
  if (progressDiv) progressDiv.textContent = `Analyzing 0 / ${raw.length}…`;

  const CONCURRENCY = provider === 'mistral' ? 3 : 5;
  let doneCount = 0;
  const analysisTasks = raw.map(article => async () => {
    const analysis = await analyzeArticle(article, apiKey, provider);
    return { ...article, ...analysis, analyzed: true };
  });

  await runConcurrent(analysisTasks, CONCURRENCY, async (idx, result) => {
    if (!result) return;
    stories.push(result);
    doneCount++;
    const pct = 25 + Math.round((doneCount / raw.length) * 70);
    if (progFill) progFill.style.width = pct + '%';
    if (progressDiv) progressDiv.textContent = `Analyzed ${doneCount} / ${raw.length}…`;
    await appendStoryCard(result);
    if (doneCount % 5 === 0 || doneCount === raw.length) { renderStats(); renderFilterRow(); }
  });

  await renderStories();
  renderStats();
  renderFilterRow();
  if (progFill) progFill.style.width = '100%';
  if (progressDiv) progressDiv.textContent = `✅ Done — ${stories.length} item${stories.length>1?'s':''} analyzed`;
  setTimeout(() => { if (progressDiv) progressDiv.textContent = ''; if (progFill) progFill.style.width = '0%'; }, 2500);
  if (analyzeBtn) analyzeBtn.disabled = false;
}

// ==================== INIT ====================
async function initDashboard(user) {
  await Promise.all([
    loadSettingsUI(),
    renderUsageBar(),
    renderTabLocks(),
    renderAccountPane(user),
    renderSettingsTrialNote(),
    window.renderTrialBanner('trialBannerContainer')
  ]);

  renderPageInfo();

  document.getElementById('analyzeBtn')?.addEventListener('click', runPageAnalysis);
  document.getElementById('refreshBtn')?.addEventListener('click', runPageAnalysis);
  document.getElementById('settingsBtn')?.addEventListener('click', () => document.querySelector('.db-tab[data-tab="settings"]').click());
  document.getElementById('saveSettingsBtn')?.addEventListener('click', saveSettingsHandler);

  document.getElementById('providerMistral')?.addEventListener('click', () => {
    settings.aiProvider = 'mistral';
    document.getElementById('providerMistral')?.classList.add('active');
    document.getElementById('providerAnthropic')?.classList.remove('active');
    document.getElementById('groupMistralKey').style.display = 'block';
    document.getElementById('groupAnthropicKey').style.display = 'none';
  });
  document.getElementById('providerAnthropic')?.addEventListener('click', () => {
    settings.aiProvider = 'anthropic';
    document.getElementById('providerAnthropic')?.classList.add('active');
    document.getElementById('providerMistral')?.classList.remove('active');
    document.getElementById('groupAnthropicKey').style.display = 'block';
    document.getElementById('groupMistralKey').style.display = 'none';
  });

  // Tab switching
  document.querySelectorAll('.db-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.db-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.db-pane').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`pane-${tab.dataset.tab}`)?.classList.add('active');
    });
  });

  // Brief and draft manual buttons
  document.getElementById('briefManualBtn')?.addEventListener('click', async () => {
    if (!await canUseBriefs()) { renderUpsellBanner('briefsContent', 'briefs'); return; }
    const topic = document.getElementById('briefTopicInput')?.value.trim();
    const tone = document.getElementById('briefToneInput')?.value || '';
    if (!topic) { document.getElementById('briefsContent').innerHTML = '<div class="error-msg">Please enter a topic or keyword.</div>'; return; }
    generateBriefFromTopicWithTone(topic, tone);
  });
  document.getElementById('briefTopicInput')?.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('briefManualBtn')?.click(); });

  document.getElementById('draftManualBtn')?.addEventListener('click', async () => {
    if (!await canUseDrafts()) { renderUpsellBanner('draftContent', 'drafts'); document.querySelector('.db-tab[data-tab="draft"]').click(); return; }
    const prompt = document.getElementById('draftPromptInput')?.value.trim();
    const wordCount = document.getElementById('draftWordCount')?.value || '1000';
    const style = document.getElementById('draftStyleInput')?.value || 'AP style';
    if (!prompt) { document.getElementById('draftContent').innerHTML = '<div class="error-msg">Please describe the article you want to write.</div>'; return; }
    generateDraftFromPrompt(prompt, wordCount, style);
  });

  // Humanizer
  document.getElementById('hzRunBtn')?.addEventListener('click', async () => {
    if (!await canUseDrafts()) { renderUpsellBanner('hzOutput', 'drafts'); document.getElementById('hzOutput').style.display = 'block'; return; }
    const text = document.getElementById('hzInput')?.value.trim();
    if (!text || text.length < 50) { document.getElementById('hzProgressMsg').textContent = '⚠️ Please paste an article (min 50 chars).'; return; }
    const persona = document.getElementById('hzPersona')?.value || 'journalist';
    const tone = document.getElementById('hzTone')?.value || 'casual';
    const bypassLevel = document.getElementById('hzBypassLevel')?.value || 'medium';
    const seoMode = document.getElementById('hzSeoMode')?.value || 'basic';
    const focusKeyword = document.getElementById('hzKeyword')?.value.trim() || '';
    const hzRunBtn = document.getElementById('hzRunBtn');
    const hzOutput = document.getElementById('hzOutput');
    if (hzRunBtn) hzRunBtn.disabled = true;
    if (hzOutput) hzOutput.style.display = 'none';
    const result = await runAdvancedHumanizer({ text, persona, tone, bypassLevel, seoMode, focusKeyword, targetDiv: hzOutput, onComplete: null });
    if (hzRunBtn) hzRunBtn.disabled = false;
    if (result) {
      const outputText = document.getElementById('hzOutputText');
      if (outputText) outputText.textContent = result;
      if (hzOutput) hzOutput.style.display = 'block';
      const sentences = result.match(/[^.!?]+[.!?]+/g) || [];
      const lens = sentences.map(s => s.trim().split(/\s+/).length);
      const avg = lens.reduce((a, b) => a + b, 0) / (lens.length || 1);
      const variance = lens.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / (lens.length || 1);
      const burstScore = Math.min(Math.round(Math.sqrt(variance) * 5), 99);
      const boosts = { aggressive: 20, medium: 10, light: 5 };
      const passScore = Math.min(burstScore + (boosts[bypassLevel] || 10), 99);
      const passCount = { light: '1', medium: '2', aggressive: '3' }[bypassLevel] || '2';
      const scoreBadges = document.getElementById('hzScoreBadges');
      if (scoreBadges) scoreBadges.innerHTML = `<span style="font-size:11px;padding:3px 10px;border-radius:20px;background:rgba(139,201,127,0.15);color:#8BC97F;border:1px solid rgba(139,201,127,0.3)">Burstiness: ${burstScore}%</span><span style="font-size:11px;padding:3px 10px;border-radius:20px;background:rgba(245,176,66,0.15);color:var(--accent);border:1px solid rgba(245,176,66,0.3)">Human Score: ~${passScore}%</span><span style="font-size:11px;padding:3px 10px;border-radius:20px;background:rgba(155,126,222,0.15);color:#9B7EDE;border:1px solid rgba(155,126,222,0.3)">${passCount}-pass</span>`;
      ['hzCopyBtn','hzExportBtn','hzRehumanizeBtn'].forEach(id => document.getElementById(id)?.replaceWith(document.getElementById(id).cloneNode(true)));
      document.getElementById('hzCopyBtn')?.addEventListener('click', () => navigator.clipboard?.writeText(result));
      document.getElementById('hzExportBtn')?.addEventListener('click', () => { const blob = new Blob([result], { type: 'text/markdown' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `humanized-${Date.now()}.md`; a.click(); });
      document.getElementById('hzRehumanizeBtn')?.addEventListener('click', () => { const input = document.getElementById('hzInput'); if (input) input.value = result; document.getElementById('hzRunBtn')?.click(); });
    }
  });

  document.getElementById('hzStripMarkdownBtn')?.addEventListener('click', () => {
    const outputDiv = document.getElementById('hzOutputText');
    if (!outputDiv) return;
    outputDiv.textContent = stripMarkdown(outputDiv.textContent);
    const msg = document.getElementById('hzProgressMsg');
    if (msg) { msg.textContent = '✓ Markdown removed'; setTimeout(() => { msg.textContent = ''; }, 2000); }
  });

  console.log('Dashboard initialised (per-page mode)');
}

window.onAuthStateChecked = (user, profile) => {
  const authGate = document.getElementById('authGate');
  const userDash = document.getElementById('userDashboard');
  if (user) {
    if (authGate) authGate.style.display = 'none';
    if (userDash) userDash.style.display = 'block';
    if (!window._dashboardInitialized) {
      window._dashboardInitialized = true;
      initDashboard(user);
    }
  } else {
    if (authGate) authGate.style.display = 'block';
    if (userDash) userDash.style.display = 'none';
    window._dashboardInitialized = false;
  }
};

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('signInPromptBtn')?.addEventListener('click', () => window.showAuthModal('login'));
  document.getElementById('registerPromptBtn')?.addEventListener('click', () => window.showAuthModal('register'));
});
